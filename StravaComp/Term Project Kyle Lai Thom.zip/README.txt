Kyle Lai Thom  
101261813

Install instructions:
npm install

Launch instructions:
node .\server.js

Testing links:
http://localhost:3000/

Youtube Demonstration:
https://youtu.be/VxFFnVfovAQ

notes:
need a Strava account to work

Logins:
guest:
username: jlaithom
password: Testing123

admin:
username: klaithom
password: Waterbottle8